package seleniumProject;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class basiclocators {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shalini\\Downloads\\Driver\\chromedriver.exe");
		ArrayList<Object> obj=new ArrayList<Object>();
		//instantiate the driver
		FirefoxDriver driver = new FirefoxDriver();
		
		//specify the URL of the webpage
		driver.get("https://testautomationpractice.blogspot.com/");
		
		Thread.sleep(10000);
		String s=driver.getTitle();
		driver.findElement(By.xpath("//input[@id='name']")).clear();
		
		driver.findElement(By.xpath("//input[@id='name']")).sendKeys("ruba");
		
		Thread.sleep(4000);
		
		
		
		Select a=new Select(driver.findElement(By.id("country")));
		a.selectByIndex(0);
		Thread.sleep(1000);
		a.selectByValue("canada");
		Thread.sleep(1000);
		a.selectByVisibleText("Germany");
		
	
		
	/*	driver.switchTo().parentFrame(); // parent frame
		String mainpage=driver.findElement(By.xpath("//div[@id='framesWrapper']//div[1]")).getText();
		System.out.println(mainpage);
		*/
		
		
	  
		driver.close();
		
	}

}
