package seleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Radiobutton {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		//System.setProperty("webdriver.gecko.driver","D://Automation notes JAVA//Selenium Drivers//Drivers//FirefoxDriver.exe");

				WebDriver driver=new FirefoxDriver();

				String baseurl="https://demo.nopcommerce.com/register";
				driver.get(baseurl);
				Thread.sleep(4000);
				  WebElement radiobutton = driver.findElement(By.id("gender-male"));
				  radiobutton.click();
				  
				System.out.println( radiobutton.isEnabled());
				 System.out.println(radiobutton.isSelected());
				 System.out.println( radiobutton.isDisplayed());
		 
		 
		 Thread.sleep(4000);
		 
		 driver.close();
		 
		 
		 
	}

}
