package seleniumProject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class testingmethods {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver=new FirefoxDriver();
		
				String baseurl="https://www.google.com";
				driver.get(baseurl);
				driver.manage().window().maximize();
			/*	List<WebElement> a = driver.findElements(By.xpath("//span[@class='text' and contains(text(),'Frames')]"));
				WebElement b=a.get(0);*/
				driver.get("https://www.facebook.com/");
				Thread.sleep(2000);
				driver.navigate().back();
				Thread.sleep(2000);
				driver.navigate().forward();
				Thread.sleep(2000);
				driver.navigate().refresh();
				Thread.sleep(2000);
				driver.navigate().to("https://www.google.com");

	}

}
