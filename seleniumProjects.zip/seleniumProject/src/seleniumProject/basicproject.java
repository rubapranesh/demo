package seleniumProject;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class basicproject {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		//System.setProperty("webdriver.gecko.driver","D://Automation notes JAVA//Selenium Drivers//Drivers//FirefoxDriver.exe");
		
				WebDriver driver=new FirefoxDriver();
				
				driver.get("https://demoqa.com/buttons");
				
				//locators ID,Name,class name,xpath,css,linked text,partial link text,tagname
				//click
				//getTitle
				//getText
				//driver.navigate().to();
				//driver.getPageSource();
				//driver.navigate().back();
				//driver.navigate().forward();
				//driver.findElement
				//driver.findElements
				//System.out.println( checkbooklinkclickone.isEnabled());
				//System.out.println( checkbooklinkclickone.isSelected());
				// System.out.println( checkbooklinkclickone.isDisplayed());
				//Selectbyvisibletext
				//selectbyIndex
				//selectbyvalue
				//action.sendkeys
				//action.click
				//action.doubleclick
				//action.keysUp
				//action.keysDown
				//action.sendkeys(element,"string").build().perform()
				//driver.findElement(By.cssSelector(�<tagname>#<id value>�));
				//driver.findElement(By.cssSelector(�<tagname>.<class value>�));
				//driver.findElement(By.cssSelector(�<tagname>[href=�<href value>�]�));
				//driver.findElement(By.cssSelector(�<tagname>.<class value>[href=�<href value>�]�));
				//webtable - use for loop
				//driver.switchTo().frame(e);
				//driver.switchTo().parentFrame();
				//driver.switchTo().defaultContent();
			    // ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
				//driver.getWindowHandle()
				
				//testNG
				//maven - install
				//testNg -install
				//create maven project
				//update the pom with libarys
				//anotations
				//anotations hieracy - alphabatic order of method wise
				//method level periorty
				//class level hieracy using testng.xml
				//depondsonmethods
				//grouping
				//listeners
				//parameters
				//enable
				//assert
				
				
				
				
				
				
				
			Thread.sleep(2000);
				
		
	}

}
