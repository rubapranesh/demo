package com.hyr.PracticeTestNG;

import org.testng.Assert;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Parameter {
	@Test
	@Parameters({"Name","b"})
	
	public void printName(@Optional String Name,@Optional String a) {
		System.out.println("name is "+ Name);
		System.out.println("a value is "+ a);
		
	    
	    // Assert.assertTrue(1>2, "positive test case");
	}
}
