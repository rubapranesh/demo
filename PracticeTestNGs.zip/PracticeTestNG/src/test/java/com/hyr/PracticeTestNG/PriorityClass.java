package com.hyr.PracticeTestNG;

import org.testng.annotations.Test;

public class PriorityClass {
    @Test(priority=-1)
	public void startthecar() {
		System.out.println("Start the car");
	}
    
    @Test(priority=0)
	public void FirstGEAR() {
		System.out.println("FirstGEAR");
	}
    
    @Test(priority=2,enabled=true)
	public void SecondGEAR() {
		System.out.println("SecondGEAR");
	}
    
    @Test(priority=3)
	public void ThirdGEAR() {
		System.out.println("ThirdGEAR");
	}
    
    @Test(priority=4)
	public void ForthGEAR() {
		System.out.println("ForthGEAR");
	}
    @Test(priority=5)
   	public void TurntheMusicON() {
   		System.out.println("TurntheMusicON");
   	}
	
}
