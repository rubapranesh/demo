package com.hyr.PracticeTestNG;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.bonigarcia.wdm.managers.ChromeDriverManager;
import io.github.bonigarcia.wdm.managers.FirefoxDriverManager;

import static org.testng.Assert.fail;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class TestClass {
	WebDriver driver;
	@BeforeSuite
	public void lanchbrowser() throws InterruptedException{
		//WebDriverManager.chromedriver().setup();
		//WebDriverManager.firefoxdriver().setup();
		 driver=new FirefoxDriver();
		driver.manage().window().maximize();
		
	}
	@Test
	public void bGoogleSearchMethod() throws InterruptedException {
		System.out.println("first    ");
		//driver install
		driver.get("https://www.google.com/");
		driver.findElement(By.name("q")).sendKeys("java tutorials");
		System.out.println(driver.getTitle());
		System.out.println("First check    ");
		Boolean a=true;
		Boolean b=false;
		Assert.assertEquals(a, b);
		Thread.sleep(2000);
	}
	@Test
	public void afirstFacebookmethd() throws InterruptedException {
		System.out.println("Second    ");
		driver.get("https://www.faceboo.com/");
		Boolean a=true;
		Boolean b=false;
		Assert.assertEquals(a, b);
		//driver.findElement(By.name("q")).sendKeys("java tutorials");
		System.out.println(driver.getTitle());
		System.out.println("Second check   ");
		Thread.sleep(2000);
	}
	
	@AfterSuite
	public void closebrowser() {
		driver.quit();
	}
   /*public void Thirdmethod() {
		System.out.println("Third    ");
	}
	public void Fourthmethod() {
		System.out.println(" Four    ");
	}*/
	
	

}
