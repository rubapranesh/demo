package com.hyr.PracticeTestNG;

import org.testng.annotations.Test;

public class GroupingEX {

	
	@Test(groups= {"Fruits"})
	public void Apple() {
		System.out.println("Apple");
		
	}
	
    @Test(groups= {"Fruits"})
	public void orange() {
		System.out.println("orange");
	}
    
    
/*    @Test(timeOut=2000,expectedExceptions=ArrayIndexOutOfBoundsException.class)*/
    @Test(groups="carsbrands")
	public void AUDI() {

		System.out.println("A7");
	}
    @Test(groups="carsbrands")
    public void BENZ() {
		System.out.println("X3");
	}
}
