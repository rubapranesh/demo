package com.hyr.PracticeTestNG;

import static org.testng.Assert.fail;

import org.testng.annotations.Test;

import dev.failsafe.internal.util.Assert;

public class handleDependencies {

	@Test(enabled=true)
	public void HighSchool() {
		System.out.println("Highschool");
		Assert.isTrue(1<2, "positive test case");
	}
    @Test(dependsOnMethods="HighSchool",enabled=true)
	public void HigherSecondary() {
		System.out.println("Highersecondary");
		Assert.isTrue(1>2, "nagative test case");
	}
    @Test(dependsOnMethods="HigherSecondary")
	public void Engineering() {
		System.out.println("Enginnering");
		
	}
}
